<template>
  <div id="app">
      <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app',
  data () {
    return {
     
    }
  }
}
</script>

<style>
@import url("./assets/css/style.css");
@import url("./assets/font_icon/iconfont.css");
</style>
