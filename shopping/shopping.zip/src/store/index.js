import Vue from "vue"
import Vuex from "vuex"
import axios from "axios";
import { getCookie } from "../utils/cookies"
import router from "../router/index"
Vue.use(Vuex)
let store = new Vuex.Store({
    state: {
        lists: {},
        shopCar: [],
        checkAll: true,
        check: true,
        count: null,
        n: null,
        deleteArr: []

    },
    actions: {
        getData_A({ commit, state }, id) {
            if (!state.lists[id]) {
                axios.get(`/proxy/index.php?ctl=goods_class&act=ajaxGetClassList&cid=${id}`).then(res => {
                    commit("getData_M", {
                        id: id,
                        data: res.data
                    })
                });
            }
        },
        getCart_A({ commit }, payload) {
            axios.post("http://192.168.191.1:3000/getShopitem", { token: getCookie("token") }).then(res => {
                if (res.data.code == 0) {
                    router.push({ name: "login", params: { from: "shop" } })
                } else {
                    commit("getCart_M", res.data.data)
                }
            });
        },
        checkItem_A({ commit }, payload) {
            commit("checkItem_M", payload)
        },
        checkAll_A({ commit }) {
            commit("checkAll_M")
        }

    },
    mutations: {
        getData_M(state, payload) {
            let obj = { ...state.lists }
            obj[payload.id] = payload.data.secondLevelCategories;
            state.lists = obj;
        },
        getCart_M(state, payload) {
            let obj = [...payload]
            obj.map(i => {
                i.check = true;
                return i
            })
            console.log(obj)
            state.shopCar = obj;
        },
        checkItem_M(state, payload) {
            let arr = [...state.shopCar]
            arr.map(i => {
                if (i.wname == payload.wname) {
                    i.check = !i.check;
                    return i
                }
            })
        },
        checkAll_M(state, payload) {
            let arr = [...state.shopCar]
            arr.map(i => {
                i.check = !i.check;
                return i

            })
        }

    }
})
export default store;